﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sklep_muzyczny
{
    class Search
    {
        public static List<Instrumenty> GetRecords(string nazwa)
        {
            InstrumentsEntities baza = new InstrumentsEntities();
            return baza.Instrumenty.Select(z => z).Where(z => z.Nazwa.StartsWith(nazwa)).ToList();
        }
    }
}
