﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Sklep_muzyczny
{
    /// <summary>
    /// Interaction logic for InstrumentWindow.xaml
    /// </summary>
    public partial class InstrumentWindow : Window
    {

        
        Instrumenty selected;
        Cart temporaryCart;

        public InstrumentWindow(Instrumenty inst, ref Cart cart)
        {
           
            InitializeComponent();
            Nazwa.Content = inst.Nazwa;
            Cena.Content = inst.Cena;
            Marka.Content = inst.Marka;
            if(!(inst.Sound_path == null || inst.Sound_path == ""))
                { sound_sample.Source = new Uri(inst.Sound_path, UriKind.Absolute); }
            sound_sample.LoadedBehavior = MediaState.Manual;
            Waluta.Content = inst.Waluta;
            selected = inst;
            temporaryCart = cart;
  
            

            //System.Windows.MessageBox.Show(inst.Sound_path);
        }



        private void Play_Click(object sender, RoutedEventArgs e)
        {
 
             sound_sample.Play();
             
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            var m = this.FindResource("wInstr") as Window;
            m.Show();           
        }

        private void Dodaj_Click(object sender, RoutedEventArgs e)
        {
            temporaryCart.Dodaj(selected);
        }


    }
}
