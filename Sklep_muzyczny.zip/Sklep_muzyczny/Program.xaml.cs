﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Sklep_muzyczny
{
    /// <summary>
    /// Interaction logic for Program.xaml
    /// </summary>
    public partial class Program : Window
    {
        bool login;
        string role;
        string Loginn;
        Cart koszyk;

        public Program()
        {
            InitializeComponent();
            koszyk = new Cart();

        }
        public Program(string role, bool login, string Login)
        {
            InitializeComponent();
            this.login = login;
            this.role = role;
            this.Loginn = Login;

            CheckLogin(Login);
            koszyk = new Cart();
        }
         
        public void CheckLogin(string Login)
        {
            if (role == "Admin" && login == true)
            {
                DodajInstr.Visibility = Visibility.Visible;
                Koszyk.Visibility = Visibility.Hidden;
                checkLogin.Content = "Jesteś zalogowany jako: " + role + ".";
            }
            else if (role == "User" && login == true)
            {
                checkLogin.Content = "Jesteś zalogowany jako: " + Login + ".";
              
                
            }
            else
            {
                checkLogin.Content = "Nie jesteś zalogowany.";
                DodajInstr.Visibility = Visibility.Hidden;
                Koszyk.Visibility = Visibility.Visible;
            }

        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Window w = new LoginWindow();
            w.Show();
            this.Hide();
            w.Resources.Add("wProgram", this);
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            Window w = new RegisterWindow();
            w.Show();
            this.Hide();
            w.Resources.Add("wRegister", this);
        }

        private void Koszyk_Click(object sender, RoutedEventArgs e)
        {
            
            Window w = new Koszyk();
            w.Resources.Add("Dane", koszyk);
            w.Show();
            this.Hide();
            w.Resources.Add("wKoszyk", this);
       
        }

        private void Szukaj_Click(object sender, RoutedEventArgs e)
        {
            SearchBox_GridPanel.Children.Clear();
            var offset = 0;
                    
            foreach (var item in Search.GetRecords(SearchBox.Text))
            {
                Label SearchBoxL = new Label();
                SearchBoxL.Height = 40;
                SearchBoxL.Width = SearchBox.Width;
                SearchBoxL.HorizontalAlignment = HorizontalAlignment.Left;
                SearchBoxL.VerticalAlignment = VerticalAlignment.Top;
                SearchBoxL.Margin = new Thickness(0,offset,0,0);
                SearchBoxL.Content = item.Nazwa;
                SearchBoxL.MouseLeftButtonDown += SearchBoxL_MouseLeftButtonDown;
                SearchBoxL.Resources.Add("instrument", item);

                SearchBox_GridPanel.Children.Add(SearchBoxL);

                offset += 40;

            }

        }

        private void SearchBoxL_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            Label i = sender as Label;
            Instrumenty instrument = i.FindResource("instrument") as Instrumenty;
            Window w = new InstrumentWindow(instrument, ref koszyk);


            w.Show();
            this.Hide();
            w.Resources.Add("wInstr", this);

            


        }

        private void DodajInstr_Click(object sender, RoutedEventArgs e)
        {
            Window w = new MainWindow();
            w.Show();
            this.Hide();
            w.Resources.Add("wDodaj", this);
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            this.login = false;
            CheckLogin(Loginn);
        }

        private void SearchBox_GotFocus(object sender, RoutedEventArgs e)
        {
            SearchBox.Text = "";
        }
    }
}
