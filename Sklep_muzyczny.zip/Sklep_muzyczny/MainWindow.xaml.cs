﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sklep_muzyczny
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Cart tempCart;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Dodaj_Click(object sender, RoutedEventArgs e)
        {
            Instrumenty.DodajInstrument(Nazwa.Text, int.Parse(Cena.Text), Marka.Text, soun_sample.Text, Image.Text, Waluta.Text);
        }
        private void Nazwa_GotFocus(object sender, RoutedEventArgs e)
        {
            Nazwa.Text = "";
        }

        private void Cena_GotFocus(object sender, RoutedEventArgs e)
        {
            Cena.Text = "";
        }



        private void Show_all_Click(object sender, RoutedEventArgs e)
        {
            
        }


        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            Lista.Items.Clear();

            var baza = new InstrumentsEntities();

            var lista = baza.Instrumenty.Select(z => z).ToList();

            foreach (var instrument in lista)
            {
                ListBoxItem itm = new ListBoxItem();
                itm.Content = instrument.Nazwa + " ";
                itm.MouseDoubleClick += Przejdz;
                itm.Resources.Add("instrument", instrument);

                Lista.Items.Add(itm);
            }
        }

        private void Przejdz(object sender, MouseButtonEventArgs e)
        {
            ListBoxItem item = sender as ListBoxItem;
            var inst = item.FindResource("instrument") as Instrumenty;
            Window w = new InstrumentWindow(inst, ref tempCart);
            w.Show();
            this.Hide();
            w.Resources.Add("mWindow", this);
            
        }

        private void Usun_Click(object sender, RoutedEventArgs e)
        {
            Instrumenty.UsunInstrument(Nazwa.Text);
            


        }

        private void Marka_GotFocus(object sender, RoutedEventArgs e)
        {
            Marka.Text = "";
        }

        private void soun_sample_GotFocus(object sender, RoutedEventArgs e)
        {
            soun_sample.Text = "";
        }

        private void Image_GotFocus(object sender, RoutedEventArgs e)
        {
            Image.Text = "";
        }

        private void Waluta_GotFocus(object sender, RoutedEventArgs e)
        {
            Waluta.Text = "";
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            var m = this.FindResource("wDodaj") as Window;
            m.Show();

        }
    }
}
