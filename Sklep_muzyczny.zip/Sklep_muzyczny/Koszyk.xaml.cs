﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Sklep_muzyczny
{
    /// <summary>
    /// Interaction logic for Koszyk.xaml
    /// </summary>
    public partial class Koszyk : Window
    {
     
        public Koszyk()
        {
            InitializeComponent();
          

        }

        public void SendCart()
        {
            var m = this.FindResource("Dane") as Cart;

            koszykLista.Items.Clear();


            int suma = 0;
            

            foreach (var instrument in m.koszyk)
            {
                ListBoxItem itm = new ListBoxItem();
                itm.Content = instrument.Nazwa + " ";
                //itm.MouseDoubleClick += Przejdz;
                itm.Resources.Add("instrument", instrument);

                koszykLista.Items.Add(itm);

                suma += (int)instrument.Cena;
                
            }
            
                sumaCena.Content = suma.ToString();
            
        }



        private void Window_Closed(object sender, EventArgs e)
        {
            var m = this.FindResource("wKoszyk") as Window;
            m.Show();


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SendCart();
        }

        private void clear1_Click(object sender, RoutedEventArgs e)
        {
            koszykLista.Items.Clear();
            sumaCena.Content = "";
        }
    }
}
