﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sklep_muzyczny
{
    public class Cart
    {
        public List<Instrumenty> koszyk; 

        public Cart()
        {
           koszyk = new List<Instrumenty>();
        }

        public void Dodaj(Instrumenty instrument)
        {
            koszyk.Add(instrument);
        }

        

    }
}
