﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Resources;

namespace Sklep_muzyczny
{
    /// <summary>
    /// Interaction logic for RegisterWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string uzytkownik = this.login.Text;
            string haslo = this.password.Password;
            var c = CheckUsers.CheckUser(uzytkownik, haslo);

            if (c.Item1)
            {

                //var m = this.FindResource("wProgram") as Window;
                //m.Show();
                //this.Hide();

                Window w = new Program(c.Item2, c.Item1, login.Text.ToString());
                w.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Niepoprawna nazwa użytkownika lub hasło!");
            }
        }


  
   

    }
}
