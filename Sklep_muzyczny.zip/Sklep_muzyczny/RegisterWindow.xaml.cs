﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Resources;

namespace Sklep_muzyczny
{
    /// <summary>
    /// Interaction logic for RegisterWindow.xaml
    /// </summary>
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void register_Click(object sender, RoutedEventArgs e)
        {

            if (!CheckUsers.CheckUser(login.Text, password.Password).Item1)
            {
                Users.DodajUzytkownika(login.Text, password.Password);
                MessageBox.Show("Dodano użytkownika: " + login.Text + ".");
                var m = this.FindResource("wRegister") as Window;
                m.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Użytkownik o nazwie:" + login.Text +  " już istnieje!");
            }
        }

    }
}
