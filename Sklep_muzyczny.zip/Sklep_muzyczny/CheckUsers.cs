﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sklep_muzyczny
{
    class CheckUsers
    {
        public static (bool, string) CheckUser(string name, string pass)
        {
            
            InstrumentsEntities baza = new InstrumentsEntities();
            var m = baza.Users.Select(z => z).Where(z => z.Login == name && z.Password == pass).ToList();
            return m.Count == 1 ? (true, m[0].Role) : (false, "User");
            
        }
    }
}
