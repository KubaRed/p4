﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sklep_muzyczny
{
    class Registration
    {
        public Registration(string login, string haslo)
        {
            InstrumentsEntities w = new InstrumentsEntities();
            var check = w.Users.Select(e => e).First(e => e.Login == login);
            bool result = w.Users.Any(e => e.Login.Contains(login));
            
            
        }

        

    }
}
